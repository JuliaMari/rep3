var jogador1 = "x";

var pos=["z","z","z","z","z","z","z","z","z"]

var leNomes = function(){
  var nomeJ1 = prompt("Digite o nome do Jogador 1");
  document.getElementById("placarP1").innerHTML = nomeJ1 + ": ";

  var nomeJ2 = prompt("Digite o nome do Jogador 2");
  document.getElementById("placarP2").innerHTML = nomeJ2 + ": ";
}

var pontua = function(posicao){
    if (pos[parseInt(posicao)] == "z")
        {if (jogador1 == x)
            document.getElementById(posicao) = '<div class="pontua">X</div>';
            pos[parseInt(posicao)] = "X";
            jogador1 = "O";
        } else{
            document.getElementById(posicao).innerHTML = '<div class="pontua">O</div>';
            pos[parseInt(posicao)] = "O"
            jogador1 = "X"
        }
    }
